from django.shortcuts import render
from django.db.models import Sum

from ordenventa.models import FacturaElectronica, ItemOrdenVenta, OrdenVenta, OrdenDeCompra
from cronogramas.models import Pago, PagoCronograma

def dashboard(request):
    total_ingresos = round(FacturaElectronica.objects.aggregate(Sum('monto_neto_cobrar'))['monto_neto_cobrar__sum'] or 0, 2)
    total_ventas = round(FacturaElectronica.objects.aggregate(Sum('monto_neto_cobrar'))['monto_neto_cobrar__sum'] or 0, 2)
    total_compras = round(OrdenDeCompra.objects.aggregate(Sum('monto_pagado'))['monto_pagado__sum'] or 0, 2)
    total_pagos_cronograma = round(PagoCronograma.objects.aggregate(Sum('monto_pago'))['monto_pago__sum'] or 0, 2)
    total_pagos_sunat = round(Pago.objects.aggregate(Sum('monto_pagado_sunat'))['monto_pagado_sunat__sum'] or 0, 2)

    total_egresos = round(total_compras + total_pagos_cronograma + total_pagos_sunat, 2)

    # Calcular el saldo
    saldo = round(total_ingresos - total_egresos, 2)

    context = {
        'total_ingresos': total_ingresos,
        'total_ventas': total_ventas,
        'total_compras': total_compras,
        'total_egresos': total_egresos,
        'saldo': saldo,
    }

    return render(request, 'dashboard.html', context)

