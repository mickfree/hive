from django.urls import path, include
from .views import DashboardView, compra_detalle, ingresos_detalle, egresos_detalle, venta_detalle

urlpatterns = [
    path('', DashboardView.home, name='home'),
    path('compra_detalle/', compra_detalle, name='compra_detalle'),
    path('ingresos-detalle/', ingresos_detalle, name='ingresos_detalle'),
    path('egresos_detalle/', egresos_detalle, name='egresos_detalle'),
    path('venta_detalle/', venta_detalle, name='venta_detalle'),
]
