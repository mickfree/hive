from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def planning_homepage(request):
    return render(request, 'planning_homepage.html')